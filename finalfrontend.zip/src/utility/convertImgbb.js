export function convertImgbb(str = "") {
  return str.split(`"`)[1];
}
